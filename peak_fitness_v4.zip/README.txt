Peak Fitness v4

Neu in v4:
- Satzpausentimer nach jedem abgehakten Satz
- RIR pro Satz
- automatische Progressionsvorschläge aus der letzten Leistung
- Übungen hinzufügen, löschen und neu anordnen
- Trainingspläne umbenennen
- Cardio-Tracking für Stairmaster, Laufen, Wandern/Marsch und Schwimmen
- Mobility-Checkliste pro Tag
- Körpergewicht mit einfachem Verlauf
- Workout-Historie und Gesamtvolumen
- JSON-Backup Export/Import
- Urlaubs-Override bei weiterlaufendem 28-Tage-Schichtrhythmus
- PWA-Dateien (manifest + service worker)

Hinweis:
Für volle PWA-/Offline-Funktion sollte der Ordner über einen Webserver/Hosting geöffnet werden. Wenn index.html nur als lokale Datei geöffnet wird, kann der Browser Service Worker blockieren. Das eigentliche Tracking funktioniert trotzdem lokal im Browser.
